class Hadeth {
  String title;
  List<String> content;
  Hadeth({required this.title, required this.content});
}
