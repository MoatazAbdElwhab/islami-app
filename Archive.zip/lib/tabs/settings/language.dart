class Language {
  String name;
  String code;

  Language({required this.name, required this.code});
}
